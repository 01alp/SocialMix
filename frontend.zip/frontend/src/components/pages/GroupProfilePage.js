import React from 'react';

const GroupProfilePage = () => {
  return <div>GroupProfilePage</div>;
};

export default GroupProfilePage;
